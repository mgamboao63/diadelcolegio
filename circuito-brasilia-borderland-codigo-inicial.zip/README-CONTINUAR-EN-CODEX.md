# Circuito Brasilia Borderland

Prototipo inicial de un juego de carreras 3D para navegador, pensado para diez computadores conectados a la red local del Colegio Brasilia Bosa IED.

## Estado actual

- Pista ancha con curvas a izquierda y derecha.
- Diez vehículos con el mismo rendimiento.
- Controles únicamente con las cuatro flechas.
- Cámara en tercera persona, cronómetro y velocímetro.
- Colisión básica: al tocar otro vehículo se detiene el avance y hay un pequeño rebote.
- Los nueve rivales todavía son simulados localmente.

## Ejecutar el proyecto

Se requiere Node.js 22 o posterior.

```bash
npm install
npm run dev
```

Después se abre la dirección indicada por la terminal.

## Próximo objetivo para Codex

Convertir el prototipo en multijugador real para diez navegadores conectados mediante una Raspberry Pi 5 y un Mercusys Halo H30G, sin depender de Internet.

La Raspberry Pi debe ejecutar un servidor WebSocket autoritativo que controle:

1. creación de una sala de hasta diez jugadores;
2. nombres y colores únicos;
3. cuenta regresiva y salida simultánea;
4. posición, rotación, velocidad y colisiones;
5. checkpoints, vueltas y orden de carrera;
6. reconexión y cierre de la partida;
7. ganador oficial calculado por el servidor.

No confiar en tiempos o posiciones enviados directamente por el navegador. El servidor debe validar la física esencial y el orden de llegada.

## Archivos principales

- `app/page.tsx`: escena Three.js, pista, vehículos, controles y física inicial.
- `app/globals.css`: interfaz visual del juego.
- `package.json`: dependencias y comandos.

## Criterios del evento

- Diez computadores participantes.
- Todos los vehículos deben tener la misma aceleración y velocidad máxima.
- Gana la habilidad para frenar, girar y elegir la trazada.
- El juego debe funcionar completamente por red local.
- Internet no puede ser un requisito durante el Día del Colegio.
