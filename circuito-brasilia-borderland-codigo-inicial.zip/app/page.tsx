"use client";

import { useEffect, useRef, useState } from "react";
import * as THREE from "three";

const COLORS = ["#21e6c1", "#ffcc33", "#ff5c8a", "#8b7cff", "#ff7b35", "#55b9ff", "#e8ff57", "#f46cff", "#ffffff", "#55e26d"];

export default function Home() {
  const mountRef = useRef<HTMLDivElement>(null);
  const [started, setStarted] = useState(false);
  const [speed, setSpeed] = useState(0);
  const [lap, setLap] = useState(1);
  const [time, setTime] = useState(0);

  useEffect(() => {
    if (!mountRef.current) return;
    const mount = mountRef.current;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x071322);
    scene.fog = new THREE.Fog(0x071322, 55, 150);
    const camera = new THREE.PerspectiveCamera(60, mount.clientWidth / mount.clientHeight, 0.1, 400);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    renderer.shadowMap.enabled = true;
    mount.appendChild(renderer.domElement);

    scene.add(new THREE.HemisphereLight(0x9ed8ff, 0x102018, 2.3));
    const sun = new THREE.DirectionalLight(0xffffff, 2.7);
    sun.position.set(20, 35, 12); sun.castShadow = true; scene.add(sun);

    const ground = new THREE.Mesh(new THREE.PlaneGeometry(180, 130), new THREE.MeshStandardMaterial({ color: 0x164136, roughness: 0.95 }));
    ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);

    // Circuito cerrado con curvas a izquierda y derecha. La calzada mide 20 m,
    // suficiente para que diez vehículos puedan disputar diferentes trazadas.
    const circuit = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-50, 0, -6), new THREE.Vector3(-42, 0, -36),
      new THREE.Vector3(-8, 0, -48), new THREE.Vector3(33, 0, -38),
      new THREE.Vector3(52, 0, -12), new THREE.Vector3(24, 0, 10),
      new THREE.Vector3(55, 0, 34), new THREE.Vector3(20, 0, 49),
      new THREE.Vector3(-13, 0, 31), new THREE.Vector3(-48, 0, 45),
      new THREE.Vector3(-61, 0, 15),
    ], true, "catmullrom", 0.32);
    const roadWidth = 20;
    const roadPositions:number[]=[]; const roadIndices:number[]=[];
    const leftEdge:THREE.Vector3[]=[]; const rightEdge:THREE.Vector3[]=[];
    const segments=180;
    for(let i=0;i<=segments;i++){
      const t=i/segments; const p=circuit.getPointAt(t); const tangent=circuit.getTangentAt(t).normalize();
      const side=new THREE.Vector3(-tangent.z,0,tangent.x);
      const left=p.clone().addScaledVector(side,roadWidth/2); const right=p.clone().addScaledVector(side,-roadWidth/2);
      roadPositions.push(left.x,.06,left.z,right.x,.06,right.z); leftEdge.push(left.clone().setY(.12)); rightEdge.push(right.clone().setY(.12));
      if(i<segments){const n=i*2; roadIndices.push(n,n+1,n+2,n+1,n+3,n+2);}
    }
    const roadGeometry=new THREE.BufferGeometry(); roadGeometry.setAttribute("position",new THREE.Float32BufferAttribute(roadPositions,3)); roadGeometry.setIndex(roadIndices); roadGeometry.computeVertexNormals();
    const track=new THREE.Mesh(roadGeometry,new THREE.MeshStandardMaterial({color:0x222b36,roughness:.8,side:THREE.DoubleSide})); track.receiveShadow=true; scene.add(track);
    [leftEdge,rightEdge].forEach(points=>scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),new THREE.LineBasicMaterial({color:0xffcf3f}))));

    function building(x:number,z:number,w:number,d:number,h:number,color:number) {
      const b = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), new THREE.MeshStandardMaterial({color, roughness:.75}));
      b.position.set(x,h/2,z); b.castShadow=true; b.receiveShadow=true; scene.add(b);
      for(let i=-w/2+3;i<w/2;i+=6){ const win=new THREE.Mesh(new THREE.PlaneGeometry(2.4,1.4),new THREE.MeshBasicMaterial({color:0x77e5ff})); win.position.set(x+i,h*.55,z+d/2+.02); scene.add(win); }
    }
    building(0,-57,76,12,17,0xd9c7a1); building(-70,5,14,56,14,0xc9614e); building(70,5,14,56,14,0x4f79a8);
    const sign = new THREE.Mesh(new THREE.BoxGeometry(30, 5, .8), new THREE.MeshStandardMaterial({color:0x122238, emissive:0x0d4261}));
    sign.position.set(0,7,-49); scene.add(sign);

    const cars: THREE.Group[] = [];
    for(let i=0;i<10;i++){
      const car=new THREE.Group();
      const body=new THREE.Mesh(new THREE.BoxGeometry(3.2,.8,5.2),new THREE.MeshStandardMaterial({color:COLORS[i],metalness:.35,roughness:.35})); body.position.y=.75; body.castShadow=true; car.add(body);
      const cabin=new THREE.Mesh(new THREE.BoxGeometry(2.3,.7,2.1),new THREE.MeshStandardMaterial({color:0x163550,metalness:.65})); cabin.position.set(0,1.35,-.25); car.add(cabin);
      const glow=new THREE.PointLight(COLORS[i],1.4,8); glow.position.set(0,.7,2.4); car.add(glow);
      const t=(i*.006)%1; const p=circuit.getPointAt(t); const tangent=circuit.getTangentAt(t);
      car.position.copy(p); car.rotation.y=Math.atan2(tangent.x,tangent.z); scene.add(car); cars.push(car);
    }
    const player=cars[0]; camera.position.set(0,8,13);
    const startTangent=circuit.getTangentAt(0);
    const keys:Record<string,boolean>={}; let velocity=0; let last=performance.now(); let raceTime=0; let playerAngle=Math.atan2(startTangent.x,startTangent.z);
    const down=(e:KeyboardEvent)=>{ if(e.key.startsWith("Arrow")){e.preventDefault();keys[e.key]=true;} };
    const up=(e:KeyboardEvent)=>{keys[e.key]=false;}; window.addEventListener("keydown",down); window.addEventListener("keyup",up);
    let raf=0;
    const animate=(now:number)=>{
      const dt=Math.min((now-last)/1000,.05); last=now;
      if(started){
        raceTime+=dt; setTime(raceTime);
        if(keys.ArrowUp) velocity=Math.min(24,velocity+19*dt); else if(keys.ArrowDown) velocity=Math.max(-7,velocity-25*dt); else velocity*=Math.pow(.91,dt*60);
        const steer=(keys.ArrowLeft?1:0)-(keys.ArrowRight?1:0); playerAngle+=steer*1.65*dt*(velocity/24);
        player.rotation.y=playerAngle;
        const previous=player.position.clone();
        player.position.x+=Math.sin(playerAngle)*velocity*dt; player.position.z+=Math.cos(playerAngle)*velocity*dt;
        setSpeed(Math.round(Math.abs(velocity)*9));
        cars.slice(1).forEach((car,i)=>{
          const t=(raceTime*(.034+i*.00035)+(i+1)*.006)%1; const p=circuit.getPointAt(t); const tangent=circuit.getTangentAt(t);
          car.position.copy(p); car.rotation.y=Math.atan2(tangent.x,tangent.z);
        });
        // Colisión sólida: el jugador no atraviesa al rival; pierde el impulso
        // y rebota ligeramente. En multijugador esta regla vivirá en el servidor.
        if(cars.slice(1).some(car=>car.position.distanceTo(player.position)<4.1)){
          player.position.copy(previous); velocity=-Math.max(2.5,Math.abs(velocity)*.18);
        }
      }
      const desired=new THREE.Vector3(player.position.x-Math.sin(playerAngle)*11,7.5,player.position.z-Math.cos(playerAngle)*11);
      camera.position.lerp(desired,.1); camera.lookAt(player.position.x,1,player.position.z);
      renderer.render(scene,camera); raf=requestAnimationFrame(animate);
    }; raf=requestAnimationFrame(animate);
    const resize=()=>{ camera.aspect=mount.clientWidth/mount.clientHeight; camera.updateProjectionMatrix(); renderer.setSize(mount.clientWidth,mount.clientHeight); };
    window.addEventListener("resize",resize);
    return()=>{cancelAnimationFrame(raf);window.removeEventListener("resize",resize);window.removeEventListener("keydown",down);window.removeEventListener("keyup",up);renderer.dispose();mount.removeChild(renderer.domElement);};
  },[started]);

  return <main className="game-shell">
    <div className="topbar"><div className="brand"><span className="suit">♠</span><div><b>BRASILIA BORDERLAND</b><small>CIRCUITO DEL COLEGIO</small></div></div><div className="network"><i/> RED LOCAL · SALA 01 <strong>10/10</strong></div></div>
    <div className="viewport" ref={mountRef}>
      <div className="place"><span>1</span><sup>°</sup><small>POSICIÓN</small></div>
      <div className="raceinfo"><div>VUELTA <b>{lap}/3</b></div><div>TIEMPO <b>{time.toFixed(1)} s</b></div></div>
      <div className="players">{COLORS.map((c,i)=><div key={c} className={i===0?"me":""}><span style={{background:c}}>{i+1}</span><b>{i===0?"TÚ":`P${i+1}`}</b></div>)}</div>
      {!started&&<div className="start-card"><p>♠ PRUEBA DE HABILIDAD</p><h1>Circuito del Colegio</h1><div className="rule"><span>↑</span><span>↓</span><span>←</span><span>→</span><b>Todos tienen la misma velocidad.<br/>La trazada decide al ganador.</b></div><button onClick={()=>setStarted(true)}>INICIAR CARRERA</button><small>Prototipo de conducción · Multijugador local en preparación</small></div>}
      <div className="speed"><strong>{speed}</strong><span>KM/H</span><div><i style={{width:`${Math.min(speed/2.16,100)}%`}}/></div></div>
      <div className="controls"><kbd>←</kbd><kbd>↑</kbd><kbd>↓</kbd><kbd>→</kbd></div>
    </div>
  </main>;
}
